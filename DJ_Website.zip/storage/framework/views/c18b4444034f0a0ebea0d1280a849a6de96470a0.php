<?php
/**
 * Created by PhpStorm.
 * User: Darkdady
 * Date: 11/07/18
 * Time: 11:39
 */
?>
<html>
    <h1>On a une nouvelle demande de Devis !</h1>
    <br>
    <p>Name: <?php echo e($contact['name']); ?></p>
    <p>E-mail: <?php echo e($contact['email']); ?></p>
    <p>Telephone: <?php echo e($contact['telephone']); ?></p>
    <br>
    <p>Sujet:</p>
    <p><?php echo e($contact['message']); ?></p>
</html>
